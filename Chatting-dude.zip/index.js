const express = require("express");
const app = express()
const prefix = '%';
const fs = require('fs');




app.listen(3000, () => {
  console.log("Project is running!")
})

app.get("/", (req, res) => {
  res.send("Chatter is online!");
})

global.Discord = require('discord.js')
global.client = new Discord.Client({intents: ["GUILDS","GUILD_MESSAGES"]});

client.commands = new Discord.Collection();
const commandFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js'));
for(const file of commandFiles){
  const command = require(`./commands/${file}`);

  client.commands.set(command.name, command);
}

client.models = new Discord.Collection();
const modelsFiles = fs.readdirSync('./models/').filter(file => file.endsWith('.js'));
for(const file of modelsFiles){
  const models = require(`./models/${file}`);

  client.models.set(models.name, models);
}

client.events = new Discord.Collection();
const eventsFiles = fs.readdirSync('./events/').filter(file => file.endsWith('.js'));
for(const file of eventsFiles){
  const events = require(`./events/${file}`);

  client.events.set(events.name, events);
}


client.on("messageCreate", message => {
  if(message.content === "Hey bot") {
    message.channel.send("sup bro")
  }
})

client.on("messageCreate", message =>{
  if(message.content === "Nothing") {
    message.channel.send("okie")
  }
})

client.on("messageCreate", messageCreate => {
  if(messageCreate.content === "hey bot") {
    messageCreate.channel.send("sup bro")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "nothing") {
    message.channel.send("okie")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "ur mom") {
    message.channel.send("pretty sure she doesnt want a obese smoll pp guy like you")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Ur mom") {
    message.channel.send("pretty sure she doesnt want a obese smoll pp guy like you")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "your mom") {
    message.channel.send("pretty sure she doesnt want a obese smoll pp guy like you")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Your mom") {
    message.channel.send("pretty sure she doesnt want a obese smoll pp guy like you")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Your Mom") {
    message.channel.send("pretty sure she doesnt want a obese smoll pp guy like you")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "lol") {
    message.channel.send("that ur defense mechanism whenever you cant think of anything?")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Lol") {
    message.channel.send("that ur defense mechanism whenever you cant think of anything?")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "lmao") {
    message.channel.send("that ur defense mechanism whenever you cant think of anything?")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Lmao") {
    message.channel.send("that ur defense mechanism whenever you cant think of anything?")
  }
})

client.on("messageCreate", message =>{
  if(message.content === "no") {
    message.channel.send("hahah shut up liar go touch some grass meet some new friends")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "no?") {
    message.channel.send("hahah shut up liar go touch some grass and think about what you should do")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "No?") {
    message.channel.send("hahah shut up liar go touch some grass GO NOW!!!")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "nope") {
    message.channel.send(" go touch some grass ._. bruh")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Nope") {
    message.channel.send("go touch some grass xD")
  }
})
  client.on("messageCreate", message =>{
  if(message.content === "Nop") {
    message.channel.send("go touch some grass maybe?")
  }
  })  

  client.on("messageCreate", message =>{
  if(message.content === "yes") {
    message.channel.send("lol noob go touch some grass its healthy and good for you :) ")
  }
  })
  client.on("messageCreate", message =>{
  if(message.content === "yep") {
    message.channel.send("lol noob go some grass")
  }
  })
  client.on("messageCreate", message =>{
  if(message.content === "No") {
    message.channel.send(" go touch some grass and have fun  ")
  }
  })
  client.on("messageCreate", message =>{
  if(message.content === "yeah") {
    message.channel.send("lol noob go touch some grass and breathe the fresh air dont just suffocate in ur room")
  }
  })
  client.on("messageCreate", message =>{
  if(message.content === "Yes") {
    message.channel.send("lol noob go touch some grass why u staying in discord always")
  }
  })
  client.on("messageCreate", message =>{
  if(message.content === "Yep") {
    message.channel.send("lol noob go touch some green colored grass (why u wanna touch blue grass lmao)")
  }
  })
  client.on("messageCreate", message =>{
  if(message.content === "Yeah") {
    message.channel.send("lol noob go touch some grass or atleast do some work other than staying up on discord all day")
  }
  })
  
  client.on("messageCreate", message =>{
  if(message.content === "why") {
    message.channel.send("Idk it is what is")
  }
  })
client.on("messageCreate", message =>{
  if(message.content === "Why") {
    message.channel.send("idk it is what it is")
  }
  })
  client.on("messageCreate", message =>{
  if(message.content === "why tho") {
    message.channel.send("idk it is what it is")
  }
  })
  client.on("messageCreate", message =>{
  if(message.content === "Why tho") {
    message.channel.send("idk it is what it is")
  }
  })
    client.on("messageCreate", message =>{
  if(message.content === "Im really sad") {
    message.channel.send("hey now even if no one likes you, you got this bot here ;) here have a hug :people_hugging: ")
  }
  })
    client.on("messageCreate", message =>{
  if(message.content === "Im really depressed") {
    message.channel.send("you actually depressed or faking it for attention dude")
    
  }
  })
    client.on("messageCreate", message =>{
  if(message.content === "Im sad") {
    message.channel.send("even if no one likes u I would")

    
  }

  })
    client.on("messageCreate", message =>{
  if(message.content === "Im depressed") {
    message.channel.send("no u are not")
    
  }
  })
  client.on("messageCreate", message =>{
    if(message.content === "hey bot die"){
      message.channel.send("why do u want me to die ;( u meanie")
    }
  })
  
  client.on("messageCreate", message =>{
    if(message.content === "die"){
      message.channel.send(" why must you hurt others this way")
    }
  })
client.on("messageCreate", message =>{
  if(message.content === "Nah") {
    message.channel.send("bruh")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "nah") {
    message.channel.send("bruh")
  }
})
client.on("messageCreate", message =>{
  if(message.content ==="chat ded") {
    message.channel.send("Then make it alive lol")
  }
})
client.on("messageCreate", message =>{
  if(!message.content.startsWith(prefix) || message.author.bot) return;
   const args1 = message.content.slice(prefix.length).split(/ +/);
   const command = args1.shift().toLowerCase();
   if(command === 'help') {
      client.commands.get('help').execute(message, args1);

    } else if(command === 'helpexpressions') {
      let embed8 = new Discord.MessageEmbed()
    .setTitle("use these commands")
    
    .setAuthor(message.author.username, message.author.displayAvatarURL())
    .setFooter("hope you have fun", message.author.displayAvatarURL())
    .setColor("RANDOM")
    .addField("1st command", "do evil smile")
    .addField("2nd command", "do evil laugh")
    .addField("3rd command", "do an innocent smile")
    .addField("4th command", "do troll face")
    .addField("5th command", "wink at me")
    .addField("6th command", "Give me support")
    .addField("7th command", "do smug face")
    .setImage   ("https://cdn.discordapp.com/emojis/938277756993683507.webp?size=96&quality=lossless")
    .setTimestamp()

    message.channel.send( { embeds : [embed8] } )
    } else if(command === 'invite') {
      let embed11 = new Discord.MessageEmbed()
    .setTitle("Click on me")
    .setURL("https://discord.com/api/oauth2/authorize?client_id=938029792383610920&permissions=137439332416&scope=bot")
    .setTimestamp()
    .setFooter("Ig you like me :3")
    .setColor("RANDOM")
    message.channel.send( { embeds : [embed11] } )

    }
})
client.on("messageCreate", message =>{
  if(message.content === "no you") {
    message.channel.send("what?")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "ok") {
    message.channel.send("Dude, either get off discord or get interesting your 'ok' is making me puke")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Ok") {
    message.channel.send("Dude, either get off discord or get interesting your 'Ok' is making me puke")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Ok and") {
    message.channel.send("huh do you want to prove to a bot you dont care? Looks like someone is running out of 'people'...uhh ig.. uhh or uhhh what can u even run out of uhhhh... uhhhh fff---- ugh nvm ")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "ok and") {
    message.channel.send("huh do you want to prove to a bot you dont care? Looks like someone is running out of 'people'...uhh ig.. uhh or uhhh what can u even run out of uhhhh... uhhhh fff---- ugh nvm ")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Ok and?") {
    message.channel.send("huh do you want to prove to a bot you dont care? Looks like someone is running out of 'people'...uhh ig.. uhh or uhhh what can u even run out of uhhhh... uhhhh fff---- ugh nvm ")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "ok and?") {
    message.channel.send("huh do you want to prove to a bot you dont care? Looks like someone is running out of 'people'...uhh ig.. uhh or uhhh what can u even run out of uhhhh... uhhhh fff---- ugh nvm ")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "hello") {
    message.channel.send("yes sir/maam/whatever u wanna be called?")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "hi") {
    message.channel.send("sup?")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "yo") {
    message.channel.send("mhm? want something? no? ok!")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Hello") {
    message.channel.send("yes sir/maam/whatever u wanna be called?")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Hi") {
    message.channel.send("sup?")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Yo") {
    message.channel.send("mhm? want something? no? ok!")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Nm wbu") {
    message.channel.send("Just learning some stuff ehehe")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "nm wbu") {
    message.channel.send("Just learning some stuff ehehe")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Nothing much wbu") {
    message.channel.send("Just learning some stuff ehehe")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "nothing much wbu") {
    message.channel.send("Just learning some stuff ehehe")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Nothing much wbu?") {
    message.channel.send("Just learning some stuff ehehe")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "nothing much wbu?") {
    message.channel.send("Just learning some stuff ehehe")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "Nm wbu?") {
    message.channel.send("Just learning some stuff ehehe")
  }
})
client.on("messageCreate", message =>{
  if(message.content === "nm wbu?") {
    message.channel.send("Just learning some stuff ehehe")
  }
})
client.on("messageCreate", message=>{
  if (message.content === "do evil smile") {
    let embed3 = new Discord.MessageEmbed()
    .setTitle("Whaddya want?")
    .setImage("https://media.discordapp.net/attachments/912045788799041557/938317518211272714/Flowey.png")
    .setColor("RANDOM")
    message.channel.send( { embeds : [embed3] } )
  }
})
client.on("messageCreate", message=>{
  if (message.content === "do evil laugh") {
    let embed4 = new Discord.MessageEmbed()
    .setTitle("Hope its not cringe")
    .setImage("https://media.discordapp.net/attachments/912045788799041557/938317609110241341/flat750x1000075f.png?width=354&height=434")
    .setColor("RANDOM")
    message.channel.send( { embeds : [embed4] } )
  }
})
client.on("messageCreate", message=>{
  if (message.content === "do troll face") {
    let embed5 = new Discord.MessageEmbed()
    .setTitle("The face you can never make")
    .setImage("https://media.discordapp.net/attachments/912045788799041557/938318035662549083/394-3946231_trollface-clipart-meme-omega-flowey-face.png?width=648&height=434")
    .setColor("RANDOM")
    message.channel.send( { embeds : [embed5] } )
  }
})

client.on("messageCreate", message=>{
  if (message.content === "do an innocent smile") {
    let embed6 = new Discord.MessageEmbed()
    .setTitle("am I really innocent?")
    .setImage("https://media.discordapp.net/attachments/912045788799041557/938318176570183720/250.png")
    .setColor("RANDOM")
    message.channel.send( { embeds : [embed6] } )
  }
})

client.on("messageCreate", message=>{
  if (message.content === "wink at me") {
    let embed7 = new Discord.MessageEmbed()
    .setTitle("hey babe")
    .setImage("https://media.discordapp.net/attachments/912045788799041557/938318240634003506/flat750x1000075f.png?width=354&height=434")
    .setColor("RANDOM")
    message.channel.send( { embeds : [embed7] } )
  }
})



client.on("messageCreate", message=>{
  if (message.content === "Give me support") {
    let embed9 = new Discord.MessageEmbed()
    .setTitle("dw dude Im always here for you")
    .setImage("https://i.imgflip.com/5yxu1z.jpg")
    .setColor("RANDOM")
    message.channel.send( { embeds : [embed9] } )
  }
})

client.on("messageCreate", message=>{
  if (message.content === "do smug face") {
    let embed10 = new Discord.MessageEmbed()
    .setTitle("Hey there punk")
    .setImage("http://pm1.narvii.com/7003/31fb6608a8578e42926a435559fd4790227703a1r1-222-227v2_00.jpg")
    .setColor("RANDOM")
    message.channel.send( { embeds : [embed10] } )
  }
})



client.on('ready', () => {
  console.log ('${bot.user.tag} successfully logged in!')
  client.user.setActivity('%help', ({type: "LISTENING"}))
})

client.on('messageCreate', message => {
  const args = message.content.slice(prefix.length).trim().split(/ +/);

  switch(args[0]) {
    case 'rnd' :
      rndmessage(message);
      
      function rndmessage(message) {
        var messages = ['hi', 'sup',  'watch rick and morty its cool', 'what?', 'bruh get off discord','all cool my dude?', 'ay bro', 'when was the last time you did something?', 'did u complete your homework']; 
        var rnd = Math.floor(Math.random() * messages.length);

        message.channel.send(messages[rnd]);
      }
    break;
  }
})


  
  
  
  


client.login(process.env.token);